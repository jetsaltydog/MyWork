function [x,y] = OrdOfCon(f, a, b, tol, method)
% This programme calculates order of convergence, q, 
% for Bisection and Newton Raphson method.

% f = Some scalar function
% 'a' and 'b' have different meanings for each method
% tol = user-specified tolerance
% 'method' must equal '1' or '2';
% 'method = 1' is for Bisection 
% 'method = 2' is for Newton Raphson'

% Bisection method
if method == 1
    
% sol = x;
% err = y;

% a = upper limit
% b = lower limit


fa = f(a); fb = f(b);

% Matrix 'A' is filled with the values corresponding to each iterate, 'it'
A = zeros(1,100);
% 'n' is a counter that decides what value each element of 'A' is given 
n = 1;
   
if sign(fa)==sign(fb)
    error('f(a) and f(b) should have opposite sign');
end


it = 0; 
absErr = abs((b - a)/2);

% The Bisection method loop
while absErr > tol
  mid = (a + b) / 2;  fmid = f(mid);
  if fmid==0
    a = mid; b = mid;
  elseif sign(fa)~=sign(fmid)
    b = mid; fb = fmid;
  else
    a = mid; fa = fmid;
  end
  A(n) = absErr;
  n = n + 1;
  it = it + 1;
  absErr = abs((b - a)/2);
end


% sol = (a + b) / 2;
% absErr = abs((b - a)/2);
% err = absErr;

% The zeros from matrix 'A' are removed and 'A' is transposed.
A = unique(A');

% These 3 values represent a change in error from one element to the next
DeltaN1 = A(end - 3) - A(end - 4);
DeltaN2 = A(end - 2) - A(end - 3);
DeltaN3 = A(end - 1) - A(end - 2);

% Approximation for the order of convergence, 'q'.
q = log((DeltaN1/DeltaN2))/log((DeltaN2/DeltaN3));
fprintf('q ~ ')
disp(q)


% Matrices used to plot a log-log graph of delta n against delta n-1.
B = zeros(100,1);
C = zeros(100,1);

% A 'while' loop to fill matrices 'B' and 'C' with delta n-1 and delta n
% respectively
t = 1;
while t < it
    B(t) = A(t+1,1) - A(t,1);
    C(t) = A(t+2,1) - A(t+1,1);
    t = t+1;
end

% 'q' should be roughly equal to the slope
loglog(C, B, 'r')

end




% Newton Raphson Method
if method == 2
 
% r = x;
% it = y;

% Matrix 'A' serves the same purpose as for Bisection
A = zeros(1,100);

% a = the function 'f' differentiated
fdash = a;
% b = the initial guess for the root to the function, 'f'
x0 = b;

it = 0;
itmax = 20; %Change this value to what you (the user) want 

x1 = x0 - f(x0)/fdash(x0);

% The Newton Raphson Method loop
while abs(x1 - x0) > tol && it < itmax 
    it = it+1;
    x0 = x1;
    x1 = x0 - f(x0)/fdash(x0);
    A(it) = x1 - x0;  
end
 if abs (x1 - x0) > tol 
     r = [];
 else
     r = x1;
 end

% The remaining code is almost the same as that of the Bisection method. 
A = abs(unique(A'));
A(end) = [];

DeltaN1 = A(end - 3) - A(end - 4);
DeltaN2 = A(end - 2) - A(end - 3);
DeltaN3 = A(end - 1) - A(end - 2);

q = log((DeltaN1/DeltaN2))/log((DeltaN2/DeltaN3));
fprintf('q ~ ')
disp(q)

B = zeros(100,1);
C = zeros(100,1);

t = itmax + 1;
while t > 4
    B(t) = A(t - 2,1) - A(t - 3,1);
    C(t) = A(t - 1,1) - A(t - 2,1);
    t = t-1;
end

C = abs(unique(C));
B = abs(unique(B));


loglog(B, C, 'r')
end

end



