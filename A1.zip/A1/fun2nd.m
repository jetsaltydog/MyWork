function [y] = fun2nd(x)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
y = 4.*(x.^3).*exp((-x.^2)) - 6.*x.*exp((-x.^2));
end

