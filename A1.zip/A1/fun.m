function [y] = fun(x)
%This function is the second derivative for f(x) = x.*exp(-x.^2)
y = x.*exp(-x.^2); 
end

