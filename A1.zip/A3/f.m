function [y] = f(x)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
y = sin(x);
end

