xt = [[1 1 1 1 1 1 1 1]; [1 3 4 6 7 8 9 10]; [1 9 25 36 49 64 81 100]];
yt = [1 2 2 4 4 3 4 5];
xls = [1 10];
x = transpose(xt);
x1 = [1 3 4 6 7 8 9 10];
y = transpose(yt);
inv(xt*x)*(xt*y)
xls = [1 2 3 4 5 6 7 8 9]

i = 1
while i < 10
    yls(1, i) = 0.3192 + 0.6328*xls(1, i) - 0.0217*(xls(1, i)).^2
    i = i + 1
end
plot(x1, y, xls, yls)    