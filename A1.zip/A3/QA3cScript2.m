x = 1; h = 1;
fun = @(x) atan(x);
funDeriv = ((-3*fun(x) + 4*fun(x + h./2) - fun(x+h))./h)

