syms x
fun = @(x) x.^2;
[diff(fun,x)]