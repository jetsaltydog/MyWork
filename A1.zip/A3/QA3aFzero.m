I = @(x) integral(fun, x, 0);
fzero(I, 11)