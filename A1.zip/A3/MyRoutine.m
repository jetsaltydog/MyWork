function [I1, I2, I3] = MyRoutine(fun, a, b, absTol)
% This programme finds the number of sub intervals needed
% to evaluate the interval of an integral 
% within a given tolerance for Simpson's, 
% Midpoint and Trapezium rules.

% I1, I2 and I3 represent Simpson's, Midpoint and Trapezium
% rules respectively.

% fun = some real scalar function
% 'a' and 'b' represent the two intervals
% absTol = User-specified tolerance

% Initial number of steps for all 3 rules
N = 1; 
% Unique steps for each rule
N1 = 1; N2 = 1; N3 = 1; 

% Initial step size for all 3 rules
h = (b-a)./N; 
% Unique step size for each rule
h1 = (b-a)./N1; h2 = (b-a)./N2; h3 = (b-a)./N3; 

x = linspace(a,b,N+1); 


% Simpson's rule
I1 = (h/3)*(fun(a)+4*sum(fun(x(2:2:end-1)))+ ...
    2*sum(fun(x(3:2:end-2)))+fun(b)); 
I1prev = I1 - 100; 

while abs(I1 - I1prev) > absTol
    I1prev = I1;
    N1 = N1 * 2;
    h1 = (b-a)./N1;
    x = linspace(a,b,N1+1); 
    I1 = (h1/3)*(fun(a)+4*sum(fun(x(2:2:end-1)))+ ...
    2*sum(fun(x(3:2:end-2)))+fun(b));
end


% Trapezium rule
I2 = (h/2)*(fun(a)+2*sum(fun(x(2:end-1)))+fun(b));  
I2prev = I1 - 100;

while abs(I2 - I2prev) > absTol
    I2prev = I2;
    N2 = N2 + 1;
    h2 = (b-a)./N2;
    x = linspace(a,b,N2+1);
    I2 = (h2/2)*(fun(a)+2*sum(fun(x(2:end-1)))+fun(b));
end


x = linspace(a+h/2,b-h/2,N); 

% Midpoint rule
I3 = h*sum(fun(x)); 
I3prev = I3 - 100;

while abs(I3 - I3prev) > absTol 
    I3prev = I3;
    N3 = N3 + 1;
    h3 = (b-a)./N3;
    x = linspace(a+h3/2,b-h3/2,N3); 
    I3 = h3*sum(fun(x));
end

[I1 I2 I3, N1 N2 N3]
end


