function [w,x] = RK4(RHS,xspan, w0, N)

x0=xspan(1);  xend=xspan(2);

x = w0;
w=zeros(size(x));
h=(xend-x0)/N;


for i=1:N
    w(i+1)= w(i) + h;
    
    [m1] = RHS(w(i)          ,x(:,i)           );
    [m2] = RHS(w(i) + 0.5*h  ,x(:,i) + 0.5*m1*h);
    [m3] = RHS(w(i) + 0.5*h  ,x(:,i) + 0.5*m2*h);
    [m4] = RHS(w(i) +     h  ,x(:,i) +     m3*h);
    x(:,i+1) = x(:,i) + (h/6)*(m1 + 2*m2 + 2*m2 + m4);
end


plot(w,x(1,:))
[x(1,end)]
