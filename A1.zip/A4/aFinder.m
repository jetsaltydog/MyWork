function [w,x] = aFinder(RHS,xspan, w0, N)

a = 0;
w0(2) = 0;
n = 0;

A = zeros(1,100);
B = zeros(1,100);

x0=xspan(1);  xend=xspan(2);
x = w0;
w=zeros(size(x));
h=(xend-x0)/N;


while a > -1
    for i=1:N
        w(i+1)= w(i) + h;
        x(2) = a;
    
        [m1] = RHS(w(i)          ,x(:,i)           );
        [m2] = RHS(w(i) + 0.5*h  ,x(:,i) + 0.5*m1*h);
        [m3] = RHS(w(i) + 0.5*h  ,x(:,i) + 0.5*m2*h);
        [m4] = RHS(w(i) +     h  ,x(:,i) +     m3*h);
        x(:,i+1) = x(:,i) + (h/6)*(m1 + 2*m2 + 2*m2 + m4);
    end
    
        n = n + 1;
        A(n) = a;
        B(n) = x(1,N);
        a = a - 0.01;
end

plot(A,B,'r')
line(xlim,[0 0],'Color','b')
[interp1(B,A,0)]
end

