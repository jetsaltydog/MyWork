function f = lorenz(t, X)

alpha = 10;
beta = 160;
gamma = 8./3;

f = zeros(3,1);

f(1) = alpha*(X(2) - X(1));
f(2) = X(1)*(beta - X(3)) - X(2);
f(3) = X(1)*X(2) - gamma*X(3);

end

