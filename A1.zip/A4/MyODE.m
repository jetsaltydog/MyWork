% lorenz.m
%
% Imlements the Lorenz System ODE
%   dx/dt = sigma*(y-x)
%   dy/dt = x*(rho-z)-y
%   dz/dt = xy-beta*z
%
% Inputs:
%   t - Time variable: not used here because our equation
%       is independent of time, or 'autonomous'.
%   x - Independent variable: has 3 dimensions
% Output:
%   dx - First derivative: the rate of change of the three dimension
%        values over time, given the values of each dimension
function dx = MyODE(t, x)

% Standard constants for the Lorenz Attractor
sigma = 10;
rho = 28;
beta = 8/3;

% I like to initialize my arrays
dx = [0; 0; 0];

% The lorenz strange attractor
dx(1) = sigma*(x(2)-x(1));
dx(2) = x(1)*(rho-x(3))-x(2);
dx(3) = x(1)*x(2)-beta*x(3);

% Generate Solution
[t, y] = ode45('lorenz', [0 20], [10 10 10]);

% Create 3d Plot
plot3(y(:,1), y(:,2), y(:,3));

for i=1:60
      
    view(6*i, 40);   % Rotate the view

    set(gca, 'XLim', [-20 20])
    set(gca, 'YLim', [-25 25])
    set(gca, 'ZLim', [0 50])

    % Remove the axes
    axis off
    
    % Generate the file name for the new frame
    name = sprintf('frames/frame-%02d.png', i); 
    
    % Save the current figure as a png file using the 
    % file name specified above. 
    print('-dpng', name); 
end